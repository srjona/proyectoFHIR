# Bienvenido

Este Proyecto fue creado con la intención de entender un poco más sobre FHIR. Especialmente, sobre el manejo de Perfiles y cómo crear reglas que nos ayuden a restringir un dominio de los datos, para un negocio específico.

![imagen 1](./FHIR-Architecture-CDR-interaction.png)