# 1. Oscar Javier Bernal Guzman

Actualmente hace parte del equipo RELEVANT y está encargado del desarrollo técnico del Workstream de Interoperabilidad. Se espera que con este trabajo, se puedan seguir cultivando las diferentes habilidades necesarias para impulsar este reto.

# 2. Jonathan Ferney Gomez Hurtado

Actualmente hace parte del equipo Centro de Ciencias Omicas. Utilizará todo el conocimiento adquirido para la implementación de guías en Datos Genómicos.

# 3. Santiago de Jesús Franco Betancur

Actualmente hace parte del equipo RELEVANT como Arquitecto de Soluciones. Utilizará todo este conocimiento adquirido para apoyar al equipo en el entendimiento, planeación y ejecución de proyectos que impliquen Interoperabilidad en Salud.